
package com.example.campusfind.activities;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.TextView;

import com.example.campusfind.R;

public class HomeActivity extends Activity {

    Button reportButton, nearbyButton, profileButton;
    TextView heading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        heading = findViewById(R.id.heading);
        reportButton = findViewById(R.id.reportButton);
        nearbyButton = findViewById(R.id.nearbyButton);
        profileButton = findViewById(R.id.profileButton);

        reportButton.setOnClickListener(v -> {
            startActivity(new Intent(this, ReportActivity.class));
        });

        nearbyButton.setOnClickListener(v -> {
            startActivity(new Intent(this, NearbyActivity.class));
        });

        profileButton.setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
        });
    }
}
