
package com.example.campusfind;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // MainActivity is not used for login.
        // LoginActivity will be the starting screen.
    }
}
