package com.example.campusfind.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private SharedPreferences preferences;

    public SessionManager(Context context) {

        preferences = context.getSharedPreferences(
                "CampusFindSession",
                Context.MODE_PRIVATE
        );
    }

    public void saveLogin(String name, String email) {

        preferences.edit()
                .putString("name", name)
                .putString("email", email)
                .putBoolean("loggedIn", true)
                .apply();
    }

    public boolean isLoggedIn() {

        return preferences.getBoolean("loggedIn", false);
    }

    public String getName() {

        return preferences.getString("name", "");
    }

    public String getEmail() {

        return preferences.getString("email", "");
    }

    public void logout() {

        preferences.edit().clear().apply();
    }
}