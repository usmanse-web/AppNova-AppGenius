
package com.example.campusfind.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.campusfind.R;
import com.example.campusfind.database.AppDatabase;
import com.example.campusfind.models.User;
import com.example.campusfind.repositories.AuthRepository;
import com.example.campusfind.utils.SessionManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RegisterActivity extends AppCompatActivity {

    EditText etName, etEmail, etPassword, etConfirmPassword;
    Button btnRegister;

    ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(v -> {

            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim().toLowerCase();
            String password = etPassword.getText().toString();
            String confirm = etConfirmPassword.getText().toString();

            if (name.isEmpty() || email.isEmpty()
                    || password.isEmpty() || confirm.isEmpty()) {

                Toast.makeText(this,
                        "Please fill all fields",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirm)) {
                Toast.makeText(this,
                        "Passwords do not match",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            btnRegister.setEnabled(false);

            executor.execute(() -> {

                AppDatabase database = AppDatabase.getDatabase(
                        getApplicationContext()
                );

                AuthRepository repository = new AuthRepository(
                        database.userDao()
                );

                String result = repository.register(
                        name, email, password, confirm
                );

                User user = null;

                if ("SUCCESS".equals(result)) {
                    user = database.userDao().getUser(email);
                }

                User finalUser = user;
                String finalResult = result;

                runOnUiThread(() -> {

                    btnRegister.setEnabled(true);

                    if (finalUser != null) {

                        new SessionManager(this).saveLogin(
                                finalUser.id,
                                finalUser.fullName,
                                finalUser.email
                        );

                        Intent intent = new Intent(
                                RegisterActivity.this,
                                HomeActivity.class
                        );

                        intent.setFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK |
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK
                        );

                        startActivity(intent);
                        finish();

                    } else {

                        Toast.makeText(
                                RegisterActivity.this,
                                finalResult,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
