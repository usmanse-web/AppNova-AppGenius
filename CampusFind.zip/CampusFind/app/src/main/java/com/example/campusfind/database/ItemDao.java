
package com.example.campusfind.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.campusfind.models.LostFoundItem;

import java.util.List;

@Dao
public interface ItemDao {

    @Insert
    long insertItem(LostFoundItem item);

    @Query("SELECT * FROM items ORDER BY date DESC, itemCode DESC")
    List<LostFoundItem> getAllItems();

    @Query("SELECT * FROM items ORDER BY date DESC")
    List<LostFoundItem> getItemsForNearby();

    @Query("SELECT COUNT(*) FROM items")
    int getItemCount();

    @Query("SELECT * FROM items WHERE itemCode = :id LIMIT 1")
    LostFoundItem getItemById(String id);

    @Update
    void updateItem(LostFoundItem item);
}
