
package com.example.campusfind.repositories;

import android.util.Patterns;

import com.example.campusfind.database.UserDao;
import com.example.campusfind.models.User;
import com.example.campusfind.utils.PasswordUtils;

import java.util.Locale;

public class AuthRepository {

    private final UserDao userDao;

    public AuthRepository(UserDao userDao) {
        this.userDao = userDao;
    }

    public String register(
            String name,
            String email,
            String password,
            String confirmPassword) {

        name = name.trim();
        email = email.trim().toLowerCase(Locale.ROOT);

        if (name.length() < 3 ||
                !name.matches("[\\p{L} ]+")) {
            return "Enter a valid full name.";
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return "Enter a valid email.";
        }

        if (password.length() < 6 ||
                !password.matches(".*\\d.*")) {
            return "Password must contain at least 6 characters and one digit.";
        }

        if (!password.equals(confirmPassword)) {
            return "Passwords do not match.";
        }

        if (userDao.getUser(email) != null) {
            return "An account with this email already exists.";
        }

        String salt = PasswordUtils.generateSalt();

        String hash = PasswordUtils.hashPassword(
                password, salt
        );

        User user = new User(
                name,
                email,
                hash,
                salt
        );

        userDao.insertUser(user);

        return "SUCCESS";
    }

    public User login(String email, String password) {

        email = email.trim().toLowerCase(Locale.ROOT);

        User user = userDao.getUser(email);

        if (user == null) {
            return null;
        }

        if (PasswordUtils.verifyPassword(
                password,
                user.passwordSalt,
                user.passwordHash)) {

            return user;
        }

        return null;
    }
}
