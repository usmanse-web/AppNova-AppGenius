
package com.example.campusfind.utils;

import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.nio.charset.StandardCharsets;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PasswordUtils {

    public static String generateSalt() {

        byte[] salt = new byte[16];

        new SecureRandom().nextBytes(salt);

        return Base64.encodeToString(
                salt,
                Base64.NO_WRAP
        );
    }

    public static String hashPassword(
            String password,
            String saltString) {

        PBEKeySpec spec = null;

        try {

            byte[] salt = Base64.decode(
                    saltString,
                    Base64.NO_WRAP
            );

            spec = new PBEKeySpec(
                    password.toCharArray(),
                    salt,
                    120000,
                    256
            );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            byte[] hash = factory.generateSecret(
                    spec
            ).getEncoded();

            return Base64.encodeToString(
                    hash,
                    Base64.NO_WRAP
            );

        } catch (Exception e) {

            throw new IllegalStateException(
                    "Password hashing failed", e
            );

        } finally {

            if (spec != null) {
                spec.clearPassword();
            }
        }
    }

    public static boolean verifyPassword(
            String password,
            String salt,
            String savedHash) {

        byte[] newHash = hashPassword(
                password,
                salt
        ).getBytes(StandardCharsets.UTF_8);

        byte[] oldHash = savedHash.getBytes(
                StandardCharsets.UTF_8
        );

        return MessageDigest.isEqual(
                newHash,
                oldHash
        );
    }
}
