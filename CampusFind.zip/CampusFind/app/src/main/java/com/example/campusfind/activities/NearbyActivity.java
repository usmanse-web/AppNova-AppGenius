
package com.example.campusfind.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusfind.R;

public class NearbyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby);
    }
}
