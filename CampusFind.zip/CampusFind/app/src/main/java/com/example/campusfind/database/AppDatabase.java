
package com.example.campusfind.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.campusfind.models.User;
import com.example.campusfind.models.LostFoundItem;

@Database(
        entities = {User.class, LostFoundItem.class},
        version = 1,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract UserDao userDao();

    public abstract ItemDao itemDao();

    public static AppDatabase getDatabase(Context context) {

        if (INSTANCE == null) {

            synchronized (AppDatabase.class) {

                if (INSTANCE == null) {

                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "campusfind_database"
                    ).build();

                }
            }
        }

        return INSTANCE;
    }
}
