package com.example.campusfind.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "items")
public class LostFoundItem {

    @PrimaryKey
    public String itemCode;

    public String type;
    public String title;
    public String category;
    public String place;
    public String contactNumber;

    public double latitude;
    public double longitude;

    public String date;
    public String status;
    public String reportedBy;

    public LostFoundItem(
            String itemCode,
            String type,
            String title,
            String category,
            String place,
            String contactNumber,
            double latitude,
            double longitude,
            String date,
            String status,
            String reportedBy) {

        this.itemCode = itemCode;
        this.type = type;
        this.title = title;
        this.category = category;
        this.place = place;
        this.contactNumber = contactNumber;
        this.latitude = latitude;
        this.longitude = longitude;
        this.date = date;
        this.status = status;
        this.reportedBy = reportedBy;
    }
}