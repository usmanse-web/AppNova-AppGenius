package com.example.campusfind.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Index;

@Entity(
        tableName = "users",
        indices = {@Index(value = {"email"}, unique = true)}
)
public class User {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String fullName;
    public String email;
    public String passwordHash;
    public String passwordSalt;

    public User(String fullName, String email,
                String passwordHash, String passwordSalt) {

        this.fullName = fullName;
        this.email = email;
        this.passwordHash = passwordHash;
        this.passwordSalt = passwordSalt;
    }
}